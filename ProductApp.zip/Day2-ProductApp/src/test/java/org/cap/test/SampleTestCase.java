package org.cap.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.experimental.categories.Category;

public class SampleTestCase {

	@Category(GoodTestCategory.class)
	@Test
	public void test() {
		//fail("Not yet implemented");
	}
	
	
	@Category(GoodTestCategory.class)
	@Test(timeout=10)
	public void check_time_out(){
		long sum=0;
		for(long i=0;i<3223;i++)
			sum+=i;
		
		
	}
	

}
