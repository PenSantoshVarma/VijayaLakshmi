package org.cap.test;

import java.util.Arrays;
import java.util.List;

import org.cap.service.ProductService;
import org.cap.service.ProductServiceImpl;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class ParameterTestCaseSquare {
	
	private ProductService productService=new ProductServiceImpl();

	private int input;
	private int output;
	
	public ParameterTestCaseSquare(int input, int output) {
		super();
		this.input = input;
		this.output = output;
	}
	
	@Parameters
	public static List<Object[]> allParamenters(){
		return Arrays.asList(new Object[][]{
			{1,1},
			{2,4},
			{-2,4},
			{0,0},
			{5,25}
		});
	}
	
	
	@Test
	public void testFindSquare(){
	
	
		Assert.assertEquals(output, productService.findSquare(input) );
		
		
	}
	
	
	
	
}
