package org.cap.test;

import static org.junit.Assert.*;

import org.cap.dao.ProductDao;
import org.cap.dto.Product;
import org.cap.exception.InvalidQuatityException;
import org.cap.service.ProductService;
import org.cap.service.ProductServiceImpl;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class TestProductApp {

	@Mock
	private ProductDao productDao;
	
	private  ProductService productService;
	
	@BeforeClass
	public static void setUp(){
		//System.out.println("Set Up");
		//productService=new ProductServiceImpl();
	}
	
	@Before
	public void beforeTestCase(){
		
		//System.out.println("beforeTestCase");
		MockitoAnnotations.initMocks(this);
		
		productService=new ProductServiceImpl(productDao);
		
		
	}
	
	
	@After
	public void afterTestCase(){
		
		//System.out.println("afterTestCase");
		
	}
	
	@Category(BadTestCategory.class)
	@Test(expected=IllegalArgumentException.class)
	public void when_addProduct_with_null_exception() throws InvalidQuatityException{
		
		
		Product product=null;
		//System.out.println("when_addProduct_with_null_exception");
		productService.addProduct(product);
	}
	
	@Category(BadTestCategory.class)
	@Test(expected=InvalidQuatityException.class)
	public void when_addProduct_with_qty_negative() throws InvalidQuatityException{
		//productService=new ProductServiceImpl();
		//System.out.println("when_addProduct_with_qty_negative");
		Product product=new Product();
		product.setQty(-2);
		productService.addProduct(product);
	}
	
	@Category(GoodTestCategory.class)
	@Test
	public void find_product_with_dao_dependencies(){
		
		Product product=new Product();
		product.setProductId(12);
		product.setQty(100);
		product.setProductName("XYZ");
		
		//Declaration
		Mockito.when(productDao.findProduct(12)).thenReturn(product);
		
		//REal Application logic
		Product newProduct=productService.findProduct(12);
		//Product newProduct1=productService.findProduct(12);
		
		//Verification Mockito
		Mockito.verify(productDao).findProduct(12);
		
		assertEquals(product.getQty(), newProduct.getQty());
		//assertEquals(10, newProduct.getQty());
		//assertEquals(newProduct.getQty(),newProduct1.getQty());
	}
	
	@Test
	public void test(){
		
	}
	
	
}
