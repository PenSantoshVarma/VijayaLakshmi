package org.cap.test;

import static org.junit.Assert.*;

import org.junit.Assume;
import org.junit.Test;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;


@RunWith(Theories.class)
public class TestTheories {

	
	/*private int num1,num2;

	public TestTheories(int num1) {
		super();
		this.num1 = num1;
	}*/
	
	@DataPoints
	public static int[] getData(){
		return new int[]{1,0,-3,45,9,5};
	}
	
	@Theory
	public void testYourTheory(int num1,int num2){
		System.out.println(num1+"---"+num2);
		Assume.assumeTrue(num1>0&&num2>0);
		assertTrue((num1+num2)>0);
		
	}
	
	
	
	

}
