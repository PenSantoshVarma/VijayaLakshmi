package org.cap.test;

public interface BadTestCategory {

}
