package org.cap.exception;

public class InvalidQuatityException extends Exception {

}
