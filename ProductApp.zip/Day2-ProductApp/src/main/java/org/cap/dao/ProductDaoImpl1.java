package org.cap.dao;

public class ProductDaoImpl1 {
	
	public void show(){
		System.out.println("Product Implemention1");
	}

}
