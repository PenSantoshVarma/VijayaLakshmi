package org.cap.dao;

import org.cap.dto.Product;

public class ProductDaoImpl implements ProductDao{

	public boolean createProduct(Product product) {
		// TODO Auto-generated method stub
		return false;
	}

	public Product findProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

}
