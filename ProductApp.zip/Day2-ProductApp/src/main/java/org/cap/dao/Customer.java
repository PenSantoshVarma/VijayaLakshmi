package org.cap.dao;

public class Customer {

}
