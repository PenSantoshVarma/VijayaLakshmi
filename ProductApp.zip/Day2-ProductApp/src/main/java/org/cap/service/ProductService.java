package org.cap.service;

import org.cap.dto.Product;
import org.cap.exception.InvalidQuatityException;

public interface ProductService {
	
	public Product addProduct(Product product) throws InvalidQuatityException;
	
	public Product findProduct(int productId);
	
	
	public Product consumeProduct(int productId,int qty)throws InvalidQuatityException;
	public Product produceProduct(int productId,int qty)throws InvalidQuatityException;
	public int findSquare(int num);
}
