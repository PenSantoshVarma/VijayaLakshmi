package org.cap.service;

import org.cap.dao.ProductDao;
import org.cap.dto.Product;
import org.cap.exception.InvalidQuatityException;
import org.cap.util.ProductUtil;

public class ProductServiceImpl implements ProductService{
	
	private ProductDao productDao;
	
	public ProductServiceImpl(){}
	
	public ProductServiceImpl(ProductDao productDao){
		this.productDao=productDao;
	}

	public Product addProduct(Product product) throws InvalidQuatityException {
		if(product==null)
			throw new IllegalArgumentException();
		if(product.getQty()<0)
			throw new InvalidQuatityException();
		
		product.setProductId(ProductUtil.generateProductId());
		
		
		if(productDao.createProduct(product))
			return product;
		
		return null;
	}

	public Product findProduct(int productId) {
		
		return productDao.findProduct(productId);
	}

	public Product consumeProduct(int productId, int qty) throws InvalidQuatityException {
		
		if(qty<=0)
			throw new InvalidQuatityException();
		
		Product product=productDao.findProduct(productId);
		
		product.setQty(product.getQty()-qty);
		
		return product;
	}

	public Product produceProduct(int productId, int qty) throws InvalidQuatityException{
		if(qty<=0)
			throw new InvalidQuatityException();
		
		Product product=productDao.findProduct(productId);
		
		product.setQty(product.getQty()+qty);
		
		return product;
	}
	
	
	
	public int findSquare(int num){
		return num*num;
	}
	
	
	
	
	
	
	
	
	
	

}
